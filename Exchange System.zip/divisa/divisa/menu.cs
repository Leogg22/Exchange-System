﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace divisa
{
    public partial class menu : Form
    {

        public menu()
        {
            InitializeComponent();
            AbrirForm(new divisas());
        }

        private Form activeForm = null;
        private void AbrirForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelPrincipal.Controls.Add(childForm);
            panelPrincipal.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnTransacciones_Click(object sender, EventArgs e)
        {
            AbrirForm(new divisas());
        }

        private void btnAltasMonedas_Click(object sender, EventArgs e)
        {
            AbrirForm(new monedas());
        }

        private void btnRegistros_Click(object sender, EventArgs e)
        {
            AbrirForm(new transacciones());
        }

        private void btnUsuarios_Click(object sender, EventArgs e)
        {
            AbrirForm(new usuarios());
        }




    }
}

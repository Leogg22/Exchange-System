﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace divisa
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void Registrar(string usuario, string clave)
        {
            if (!usuario.All(char.IsLetterOrDigit))
            {
                MessageBox.Show("El nombre de usuario no debe contener caracteres especiales.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            OleDbConnection Consulta = new OleDbConnection(@"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;");
            if (txbUsuario.Text == "" || txbPassword.Text == "")
            {
                MessageBox.Show("Ambas cajas deben tener informacion.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                Consulta.Open();
            OleDbCommand command = new OleDbCommand("SELECT usuario,tipo FROM usuarios WHERE usuario = @usuario AND clave=@clave", Consulta);
            command.Parameters.AddWithValue("usuario", usuario);
            command.Parameters.AddWithValue("clave", clave);

            OleDbDataAdapter suda = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            suda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                if (dt.Rows[0][1].ToString() == "Admin" || dt.Rows[0][1].ToString() == "Vendedor")
                {

                    //menu formMenu = new divisas(usuario);
                    //formMenu.Show();
                    new menu().Show();
                    MessageBox.Show("Hola " + usuario, dt.Rows[0][1].ToString(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            Registrar(txbUsuario.Text, txbPassword.Text);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult salir = MessageBox.Show("Salir del programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (salir == DialogResult.No)
            {
                return;
            }
            Application.Exit();
        }

        private void txbPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                btnEntrada_Click(sender, new EventArgs());
            }
        }
    }
}

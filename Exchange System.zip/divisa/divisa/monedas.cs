﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace divisa
{
    public partial class monedas : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public monedas()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;";

            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT moneda_inicial.cod_moneda_inicial, moneda_inicial.monedai FROM moneda_inicial;";
            command.CommandText = query;

            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datamonedas.DataSource = dt;

            connection.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "insert into moneda_inicial ([monedai]) values ('" + txbMoneda.Text + "')";
            command.ExecuteNonQuery();
            connection.Close();

            connection.Open();
            OleDbCommand command2 = new OleDbCommand();
            command2.Connection = connection;
            command2.CommandText = "insert into moneda_final ([monedaf]) values ('" + txbMoneda.Text + "')";
            command2.ExecuteNonQuery();
            connection.Close();

            txbCodigo.Clear();
            txbMoneda.Clear();


            connection.Open();
            OleDbCommand command3 = new OleDbCommand();
            command3.Connection = connection;
            string query = "SELECT moneda_inicial.cod_moneda_inicial, moneda_inicial.monedai FROM moneda_inicial;";
            command3.CommandText = query;
        
            OleDbDataAdapter da = new OleDbDataAdapter(command3);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datamonedas.DataSource = dt;

            connection.Close();
        }

        private void datamonedas_SelectionChanged(object sender, EventArgs e)
        {
            {
                DataGridViewCell cell = null;
                foreach (DataGridViewCell selectedCell in datamonedas.SelectedCells)
                {
                    cell = selectedCell;
                    break;
                }
                if (cell != null)
                {
                    DataGridViewRow row = cell.OwningRow;
                    txbCodigo.Text = row.Cells[0].Value.ToString();
                    txbMoneda.Text = row.Cells[1].Value.ToString();
                    
              
                }
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txbCodigo.Clear();
            txbMoneda.Clear();
        }
    }
}

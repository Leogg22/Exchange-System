﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace divisa
{
    public partial class transacciones : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public transacciones()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;";

            connection.Open();

            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT transaccion.n_transaccion, clientes.nombre, clientes.telefono, clientes.direccion, moneda_inicial.monedai, transaccion.mi_dada, moneda_final.monedaf, transaccion.mf_dado, transaccion.valor, transaccion.descuento, transaccion.fecha FROM moneda_inicial INNER JOIN (moneda_final INNER JOIN (clientes INNER JOIN transaccion ON clientes.id_cliente = transaccion.id_cliente) ON moneda_final.cod_moneda_final = transaccion.moneda_final) ON moneda_inicial.cod_moneda_inicial = transaccion.moneda_inicial ORDER BY transaccion.n_transaccion;";
            command.CommandText = query;

            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datatransacciones.DataSource = dt;
            connection.Close();

           
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {

            string query = "SELECT transaccion.n_transaccion, clientes.nombre, clientes.telefono, clientes.direccion, moneda_inicial.monedai, transaccion.mi_dada, moneda_final.monedaf, transaccion.mf_dado, transaccion.valor, transaccion.descuento, transaccion.fecha FROM moneda_inicial INNER JOIN (moneda_final INNER JOIN (clientes INNER JOIN transaccion ON clientes.id_cliente = transaccion.id_cliente) ON moneda_final.cod_moneda_final = transaccion.moneda_final) ON moneda_inicial.cod_moneda_inicial = transaccion.moneda_inicial WHERE transaccion.n_transaccion = ? ORDER BY transaccion.n_transaccion;";

            using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info=False;"))
            {
                connection.Open();

                using (OleDbCommand mycommand = new OleDbCommand(query, connection))
                {
                    mycommand.Parameters.AddWithValue("?", txbBuscar.Text);

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(mycommand))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        datatransacciones.DataSource = dt;
                    }
                }
            }
        }

        private void transacciones_Load(object sender, EventArgs e)
        {
            cmbMonedaInicial.SelectedIndex = -1;
            cmbMonedaFinal.SelectedIndex = -1;

            connection.Open();
            string query = "SELECT fecha FROM transaccion";
            OleDbCommand command = new OleDbCommand(query, connection);
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cmbFechas.Items.Add(reader["fecha"].ToString());
            }
            connection.Close();

           //
                connection.Open();
                OleDbCommand command2 = new OleDbCommand();
                command2.Connection = connection;
                string query2 = "SELECT cod_moneda_inicial, monedai FROM moneda_inicial ORDER BY monedai;";
                command2.CommandText = query2;

                OleDbDataReader reader2 = command2.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader2);

                cmbMonedaInicial.DisplayMember = "monedai";
                cmbMonedaInicial.ValueMember = "cod_moneda_inicial";
                cmbMonedaInicial.DataSource = dt;

                reader2.Close();
                connection.Close();
            //

                connection.Open();
                OleDbCommand command3 = new OleDbCommand();
                command3.Connection = connection;
                string query3 = "SELECT cod_moneda_final, monedaf FROM moneda_final ORDER BY monedaf;";
                command3.CommandText = query3;

                OleDbDataReader reader3 = command3.ExecuteReader();
                DataTable dt2 = new DataTable();
                dt2.Load(reader3);

                cmbMonedaFinal.DisplayMember = "monedaf";
                cmbMonedaFinal.ValueMember = "cod_moneda_final";
                cmbMonedaFinal.DataSource = dt2;

                reader3.Close();
                connection.Close();


        }

        private void btnBuscarFech_Click(object sender, EventArgs e)
        {

            string fechaSeleccionada = cmbFechas.SelectedItem.ToString();
            string query = "SELECT transaccion.n_transaccion, clientes.nombre, clientes.telefono, clientes.direccion, moneda_inicial.monedai, transaccion.mi_dada, moneda_final.monedaf, transaccion.mf_dado, transaccion.valor, transaccion.descuento, transaccion.fecha FROM moneda_inicial INNER JOIN (moneda_final INNER JOIN (clientes INNER JOIN transaccion ON clientes.id_cliente = transaccion.id_cliente) ON moneda_final.cod_moneda_final = transaccion.moneda_final) ON moneda_inicial.cod_moneda_inicial = transaccion.moneda_inicial WHERE transaccion.fecha = ? ORDER BY transaccion.n_transaccion;";

            using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info=False;"))
            {
                connection.Open();

                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("?", fechaSeleccionada);

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        datatransacciones.DataSource = dt;
                    }
                }
            }
        }

        private void btnBuscarMonedaInicial_Click(object sender, EventArgs e)
        {

        }


    }
}

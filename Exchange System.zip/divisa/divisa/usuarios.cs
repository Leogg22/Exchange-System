﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace divisa
{
    public partial class usuarios : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public usuarios()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;";

            connection.Open();

            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT usuarios.id, usuarios.usuario, usuarios.clave, usuarios.tipo FROM usuarios ORDER BY usuarios.id;";
            command.CommandText = query;

            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datausuarios.DataSource = dt;
            connection.Close();

            cmbBuscar.Items.Add("ID");
            cmbBuscar.Items.Add("Usuario");
            cmbBuscar.Items.Add("Tipo");

        }

        private DataSet datos;
        private OleDbDataAdapter medio;
        int posicion;
        int posicionfinal;

        public void Cargar_Usuario()
        {
            medio = new OleDbDataAdapter("SELECT * FROM usuarios", connection);
            datos = new DataSet();
            medio.Fill(datos, "usuarios");
            posicion = 0;
            posicionfinal = (datos.Tables["usuarios"].Rows.Count) - 1;
        }

        private void mover(int paso)
        {
            posicion = posicion + paso;
            txbId.Text = datos.Tables["usuarios"].Rows[posicion][0].ToString();
            txbUsuario.Text = datos.Tables["usuarios"].Rows[posicion][1].ToString();
            txbClave.Text = datos.Tables["usuarios"].Rows[posicion][2].ToString();
            txbNivel.Text = datos.Tables["usuarios"].Rows[posicion][3].ToString();

        }

        private void Interface_Inicial()
        {
            txbId.Enabled = false;
            txbUsuario.Enabled = false;
            txbClave.Enabled = false;
            txbNivel.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;

            command.CommandText = "insert into usuarios( usuario, clave, tipo) values ('" + txbUsuario.Text + "','" + txbClave.Text + "','" + txbNivel.Text + "')";
            command.ExecuteNonQuery();

            txbId.Clear();
            txbUsuario.Clear();
            txbClave.Clear();
            txbNivel.Clear();



            string query = "SELECT usuarios.id, usuarios.usuario, usuarios.clave, usuarios.tipo FROM usuarios ORDER BY usuarios.id;";
            command.CommandText = query;
            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datausuarios.DataSource = dt;

            connection.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txbId.Clear();
            txbUsuario.Clear();
            txbClave.Clear();
            txbNivel.Clear();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "update usuarios set id='" + txbId.Text + "', usuario ='" + txbUsuario.Text + "', clave ='" + txbClave.Text + "', tipo ='" + txbNivel.Text + "' where id =" + txbId.Text + "";
            MessageBox.Show(query);
            command.CommandText = query;
            command.ExecuteNonQuery();
            MessageBox.Show("Datos Actualizados");
            connection.Close();
            txbId.Clear();
            txbUsuario.Clear();
            txbClave.Clear();
            txbNivel.Clear();

            command.Connection = connection;
            string actual = "SELECT usuarios.id, usuarios.usuario, usuarios.clave, usuarios.tipo FROM usuarios ORDER BY usuarios.id;";
            command.CommandText = actual;
            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datausuarios.DataSource = dt;

            connection.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txbId.Text))
            {
                MessageBox.Show("Por favor, seleccione un usuario para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }


            DialogResult confirmResult = MessageBox.Show("¿Esta seguro de que desea eliminar este usuario?", "Confirmar eliminacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    string userId = txbId.Text;


                    connection.Open();


                    OleDbCommand command = connection.CreateCommand();
                    command.CommandText = "DELETE FROM usuarios WHERE id = ?";


                    command.Parameters.AddWithValue("?", userId);


                    int rowsAffected = command.ExecuteNonQuery();


                    connection.Close();

                    if (rowsAffected > 0)
                    {

                        Interface_Inicial();
                        MessageBox.Show("Usuario eliminado correctamente", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Cargar_Usuario();
                        mover(0);
                    }
                    else
                    {

                        MessageBox.Show("No se encontro ningun usuario para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Error al eliminar el usuario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            OleDbCommand updateCommand = new OleDbCommand();
            updateCommand.Connection = connection;

            string actual = "SELECT usuarios.id, usuarios.usuario, usuarios.clave, usuarios.tipo FROM usuarios ORDER BY usuarios.id;";
            updateCommand.CommandText = actual;
            OleDbDataAdapter da = new OleDbDataAdapter(updateCommand);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datausuarios.DataSource = dt;
        }

        private void datausuarios_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewCell cell = null;
            foreach (DataGridViewCell selectedCell in datausuarios.SelectedCells)
            {
                cell = selectedCell;
                break;
            }
            if (cell != null)
            {
                DataGridViewRow row = cell.OwningRow;
                txbId.Text = row.Cells[0].Value.ToString();
                txbUsuario.Text = row.Cells[1].Value.ToString();
                txbClave.Text = row.Cells[2].Value.ToString();
                txbNivel.Text = row.Cells[3].Value.ToString();

            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string campoABuscar = cmbBuscar.SelectedItem.ToString();
            string valorABuscar = txbBuscar.Text;

            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;


            string query = "SELECT id,usuario,clave,tipo FROM usuarios WHERE ";

            switch (campoABuscar)
            {
                case "ID":
                    query += "id";
                    break;
                case "Usuario":
                    query += "usuario";
                    break;
                case "Tipo":
                    query += "tipo";
                    break;

                default:
                    MessageBox.Show("Campo de búsqueda no valido.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    connection.Close();
                    return;
            }

            query += " LIKE '%" + valorABuscar + "%'";
            command.CommandText = query;

            OleDbDataAdapter da = new OleDbDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datausuarios.DataSource = dt;

            connection.Close();
        }
    }
}

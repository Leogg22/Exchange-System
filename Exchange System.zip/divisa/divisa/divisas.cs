﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Data.OleDb;

namespace divisa
{
    public partial class divisas : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        string Divisa;
        public divisas()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;";
            cmbDivisa.Text = null;
            cmbCambiarA.Text = null;

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            cmbDivisa.Text = null;
            cmbCambiarA.Text = null;
            txbDescuento.Text = "";
            txbCambiar.Text = "";
            txbDireccion.Text = "";
            txbNombre.Text = "";
            txbTelefono.Text = "";
            txbTotal.Text = "";
            txbValorDivisa.Text = "";

            
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult salir = MessageBox.Show("Salir del sistema?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (salir == DialogResult.No)
            {
                return;
            }
            Application.Exit();
        }


        private void cmbDivisa_SelectedValueChanged(object sender, EventArgs e)
        {
           
            if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "MXN")
            {
                webBrowser1.Navigate("https://www.google.com/finance/quote/USD-MXN?sa=X&ved=2ahUKEwiZ6fKh742DAxXmLUQIHaMhDbYQmY0JegQIBxAr");
            }

                if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "MXN")
                {
                    webBrowser1.Navigate("https://www.google.com/finance/quote/EUR-MXN?sa=X&sqi=2&ved=2ahUKEwjH3N_0qo-DAxVbrmoFHXtyDAkQmY0JegQIExAr");
                }

                    if (cmbDivisa.Text == "MXN" && cmbCambiarA.Text == "USD")
                    {
                        webBrowser1.Navigate("https://www.google.com/finance/quote/MXN-USD?sa=X&sqi=2&ved=2ahUKEwin4LXLq4-DAxXLkyYFHePOBgkQmY0JegQIDRAr");
                        //En esta que se marque con un insert que es compra 
                    }

                        if (cmbDivisa.Text == "MXN" && cmbCambiarA.Text == "EUR")
                        {
                            webBrowser1.Navigate("https://www.google.com/finance/quote/MXN-EUR?sa=X&sqi=2&ved=2ahUKEwi1geePrI-DAxVGmGoFHd3JDwgQmY0JegQIExAr");
                            //En esta que se marque con un insert que es compra 
                        }
                        else if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "USD")
                        {
                            MessageBox.Show("solo hay cambios con moneda mexicana");
                            cmbDivisa.Text = null;
                        }
                        else if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "EUR")
                        {
                            MessageBox.Show("solo hay cambios con moneda mexicana");
                            cmbDivisa.Text = null;
                        }

                        else if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "EUR")
                        {
                            //MessageBox.Show("selecciona dos monedas diferentes");
                            cmbDivisa.Text = null;
                            cmbCambiarA.Text = null;
                        }
                        else if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "USD")
                        {
                            //MessageBox.Show("selecciona dos monedas diferentes");
                            cmbDivisa.Text = null;
                            cmbCambiarA.Text = null;
                        }
                        
         

        }

        private void cmbCambiarA_SelectedValueChanged(object sender, EventArgs e)
        {
            
            if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "MXN")
            {
                webBrowser1.Navigate("https://www.google.com/finance/quote/USD-MXN?sa=X&ved=2ahUKEwiZ6fKh742DAxXmLUQIHaMhDbYQmY0JegQIBxAr");
            }

                if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "MXN")
                {
                    webBrowser1.Navigate("https://www.google.com/finance/quote/EUR-MXN?sa=X&sqi=2&ved=2ahUKEwjH3N_0qo-DAxVbrmoFHXtyDAkQmY0JegQIExAr");
                }

                    if (cmbDivisa.Text == "MXN" && cmbCambiarA.Text == "USD")
                    {
                        webBrowser1.Navigate("https://www.google.com/finance/quote/MXN-USD?sa=X&sqi=2&ved=2ahUKEwin4LXLq4-DAxXLkyYFHePOBgkQmY0JegQIDRAr");
                    }

                        if (cmbDivisa.Text == "MXN" && cmbCambiarA.Text == "EUR")
                        {
                            webBrowser1.Navigate("https://www.google.com/finance/quote/MXN-EUR?sa=X&sqi=2&ved=2ahUKEwi1geePrI-DAxVGmGoFHd3JDwgQmY0JegQIExAr");
                            //En esta que se marque con un insert que es compra 
                        }
                        else if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "USD")
                        {
                            MessageBox.Show("solo hay cambios con moneda mexicana");
                            cmbCambiarA.Text = null;
                        }
                        else if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "EUR")
                        {
                            MessageBox.Show("solo hay cambios con moneda mexicana");
                            cmbCambiarA.Text = null;
                        }

                        else if (cmbDivisa.Text == "EUR" && cmbCambiarA.Text == "EUR")
                        {
                          //  MessageBox.Show("selecciona dos monedas diferentes");
                            cmbDivisa.Text = null;
                            cmbCambiarA.Text = null;
                        }
                        else if (cmbDivisa.Text == "USD" && cmbCambiarA.Text == "USD")
                        {
                           // MessageBox.Show("selecciona dos monedas diferentes");
                            cmbDivisa.Text = null;
                            cmbCambiarA.Text = null;
                        }
                

        }

        
        private void divisas_Load(object sender, EventArgs e)
        {
            
            //connection.Open();
            //string query = "SELECT monedai FROM moneda_inicial";
            //OleDbCommand command = new OleDbCommand(query, connection);
            //OleDbDataReader reader = command.ExecuteReader();
            //while (reader.Read())
            //{
            //    cmbDivisa.Items.Add(reader["monedai"].ToString());
            //    cmbCambiarA.Items.Add(reader["monedai"].ToString());
            //}
            //connection.Close();

            txbDescuento.Text = "0";
            cmbCambiarA.Text = null;
            cmbDivisa.Text = null;

            //connection.Open();
            //OleDbCommand command = new OleDbCommand();
            //command.Connection = connection;
            //string query = "SELECT cod_moneda_inicial, monedai FROM moneda_inicial ORDER BY monedai;";
            //command.CommandText = query;

            //OleDbDataReader reader = command.ExecuteReader();
            //DataTable dt = new DataTable();
            //dt.Load(reader);

            //cmbDivisa.DisplayMember = "monedai";
            //cmbDivisa.ValueMember = "cod_moneda_inicial";
            //cmbDivisa.DataSource = dt;

            //reader.Close();



            //OleDbCommand commandf = new OleDbCommand();
            //commandf.Connection = connection;
            //string queryf = "SELECT cod_moneda_final, monedaf FROM moneda_final ORDER BY monedaf;";
            //commandf.CommandText = queryf;

            //OleDbDataReader readerf = command.ExecuteReader();
            //DataTable dtf = new DataTable();
            //dtf.Load(readerf);

            //cmbCambiarA.DisplayMember = "monedaf";
            //cmbCambiarA.ValueMember = "cod_moneda_final";
            //cmbCambiarA.DataSource = dtf;

            //readerf.Close();

            //if (connection.State == ConnectionState.Open)
            //{
            //    connection.Close();
            //}

            OleDbCommand command = new OleDbCommand("SELECT cod_moneda_inicial, monedai FROM moneda_inicial ORDER BY monedai;", connection);
            connection.Open();
            OleDbDataReader reader = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            connection.Close();

            cmbDivisa.DisplayMember = "monedai";
            cmbDivisa.ValueMember = "cod_moneda_inicial";
            cmbDivisa.DataSource = dt;

            
            OleDbCommand commandf = new OleDbCommand("SELECT cod_moneda_final, monedaf FROM moneda_final ORDER BY monedaf;", connection);
            connection.Open();
            OleDbDataReader readerf = commandf.ExecuteReader();
            DataTable dtf = new DataTable();
            dtf.Load(readerf);
            connection.Close();

            cmbCambiarA.DisplayMember = "monedaf";
            cmbCambiarA.ValueMember = "cod_moneda_final";
            cmbCambiarA.DataSource = dtf;
        }


        private void valores()
        {
            float valordivisa;
            float.TryParse(txbValorDivisa.Text, out valordivisa);

            float montoCambiar;
            float.TryParse(txbCambiar.Text, out montoCambiar);

            float descuento;
            float.TryParse(txbDescuento.Text, out descuento);
            descuento = descuento / 100;

            float subtotal = valordivisa * montoCambiar;

            float total = subtotal - (subtotal * descuento);
            txbTotal.Text = total.ToString();

            //int c10 = 0, c20 = 0, c50 = 0;
            int m10 = 0, m5 = 0, m2 = 0, m1 = 0;
            int b20 = 0, b50 = 0, b100 = 0, b200 = 0, b500 = 0;
            float cambio = total;
            StringBuilder desgloseCambio = new StringBuilder();

            if (cambio >= 500)
            {
                b200 = (int)(cambio / 500);
                cambio = cambio - (b500 * 500);
                desgloseCambio.AppendLine(b500 + " billete(s) de 500");
            }

            if (cambio >= 200)
            {
                b200 = (int)(cambio / 200);
                cambio = cambio - (b200 * 200);
                desgloseCambio.AppendLine(b200 + " billete(s) de 200");
            }

            if (cambio >= 100)
            {
                b100 = (int)(cambio / 100);
                cambio = cambio - (b100 * 100);
                desgloseCambio.AppendLine(b100 + " billete(s) de 100");
            }

            if (cambio >= 50)
            {
                b50 = (int)(cambio / 50);
                cambio = cambio - (b50 * 50);
                desgloseCambio.AppendLine(b50 + " billete(s) de 50");
            }

            if (cambio >= 20)
            {
                b20 = (int)(cambio / 20);
                cambio = cambio - (b20 * 20);
                desgloseCambio.AppendLine(b20 + " billete(s) de 20");
            }


            if (cambio >= 10)
            {
                m10 = (int)(cambio / 10);
                cambio = cambio - (m10 * 10);
                desgloseCambio.AppendLine(m10 + " moneda(s) de 10");
            }

            if (cambio >= 5)
            {
                m5 = (int)(cambio / 5);
                cambio = cambio - (m5 * 5);
                desgloseCambio.AppendLine(m5 + " moneda(s) de 5");
            }

            if (cambio >= 2)
            {
                m2 = (int)(cambio / 2);
                cambio = cambio - (m2 * 2);
                desgloseCambio.AppendLine(m5 + " moneda(s) de 2");
            }

            if (cambio >= 1)
            {
                m1 = (int)(cambio / 1);
                cambio = cambio - (m1 * 1);
                desgloseCambio.AppendLine(m5 + " moneda(s) de 1");
            }

            lblDesgloseCambio.Text = desgloseCambio.ToString();
        }


        private void txbCambiar_TextChanged(object sender, EventArgs e)
        {
            //txbValorDivisa
            //txbCambiar        //nudDescuento
            valores();
            

        }

        private void txbDescuento_TextChanged(object sender, EventArgs e)
        {
            valores();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
             string connectionString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=..\divisa.mdb; Persist Security Info = False;";

             using (OleDbConnection connection = new OleDbConnection(connectionString))
             {

                 connection.Open();
                 OleDbCommand command = new OleDbCommand();
                 command.Connection = connection;
                 command.CommandText = "insert into clientes(nombre, telefono, direccion) values ('" + txbNombre.Text + "', '" + txbTelefono.Text + "', '" + txbDireccion.Text + "')";
                 command.ExecuteNonQuery();


                 command.CommandText = "SELECT @@IDENTITY";
                 int idCliente = (int)command.ExecuteScalar();


                 DateTime fechaActual = DateTime.Now;
                 string fechaFormateada = fechaActual.ToString("MM/dd/yyyy ");


                 //OleDbCommand commandt = new OleDbCommand();
                 //commandt.Connection = connection;
                 //commandt.CommandText = "insert into transaccion(id_cliente, moneda_inicial, moneda_final, valor, descuento, cantidad, fecha ) values ( '" + idCliente.ToString() + "', '" + cmbDivisa.Text + "', '" + cmbCambiarA.Text + "','" + txbValorDivisa.Text + "', '" + txbDescuento.Text + "', '" + txbCambiar.Text + "'  , '" + fechaFormateada + "')";
                 //commandt.ExecuteNonQuery();
                 OleDbCommand commandt = new OleDbCommand();
                 commandt.Connection = connection;
                 commandt.CommandText = "insert into transaccion(id_cliente, moneda_inicial, moneda_final, valor, descuento, mi_dada, mf_dado, fecha) values (?, ?, ?, ?, ?, ?, ?, ?)";
                 commandt.Parameters.AddWithValue("id_cliente", idCliente);

                 commandt.Parameters.AddWithValue("moneda_inicial", cmbDivisa.SelectedValue);
                 commandt.Parameters.AddWithValue("moneda_final", cmbCambiarA.SelectedValue);

                 commandt.Parameters.AddWithValue("valor", Convert.ToDouble(txbValorDivisa.Text));
                 commandt.Parameters.AddWithValue("descuento", Convert.ToDouble(txbDescuento.Text));
                 commandt.Parameters.AddWithValue("mi_dada", Convert.ToDouble(txbCambiar.Text));
                 commandt.Parameters.AddWithValue("mf_dado", Convert.ToDouble(txbTotal.Text));
                 commandt.Parameters.AddWithValue("fecha", fechaFormateada);
                 commandt.ExecuteNonQuery();

                 connection.Close();
             }

             cmbDivisa.Text = null;
             cmbCambiarA.Text = null;
             txbDescuento.Text = "";
             txbCambiar.Text = "";
             txbDireccion.Text = "";
             txbNombre.Text = "";
             txbTelefono.Text = "";
             txbTotal.Text = "";
             txbValorDivisa.Text = "";
          





        }




       
        
    }
}
